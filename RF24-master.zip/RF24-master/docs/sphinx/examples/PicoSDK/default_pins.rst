PicoSDK Examples' Default Pins
==============================

.. literalinclude:: ../../../../examples_pico/defaultPins.h
    :linenos:
