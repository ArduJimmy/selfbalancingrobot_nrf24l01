Porting: Timing
===============

.. doxygengroup:: Porting_Timing
    :members:
    :undoc-members:
    :protected-members:
    :private-members:
    :content-only:

compatibility.h
---------------

.. literalinclude:: ../../../utility/Template/compatibility.h
    :caption: utility/Template/compatibility.h
